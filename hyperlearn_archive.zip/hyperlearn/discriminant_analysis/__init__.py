
from .QDA import QuadraticDiscriminantAnalysis

__all__ = ['QuadraticDiscriminantAnalysis']